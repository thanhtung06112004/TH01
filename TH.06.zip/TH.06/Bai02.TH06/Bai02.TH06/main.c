//
//  main.c
//  Bai02.TH06
//
//  Created by le thanh tung on 16/11/2023.
//

#include <stdio.h>
struct fraction {
  int numerator;
  int denominator;
};

void input_fractions(int n, struct fraction fractions[]) {
  for (int i = 0; i < n; i++) {
    printf("Nhập phân số thứ %d: ", i + 1);
    scanf("%d/%d", &fractions[i].numerator, &fractions[i].denominator);
  }
}

struct fraction find_max_fraction(int n, struct fraction fractions[]) {
  struct fraction max_fraction = fractions[0];
  for (int i = 1; i < n; i++) {
    if (fractions[i].numerator / fractions[i].denominator >
        max_fraction.numerator / max_fraction.denominator) {
      max_fraction = fractions[i];
    }
  }
  return max_fraction;
}

struct fraction sum_fractions(int n, struct fraction fractions[]) {
  struct fraction sum_fraction = {0, 1};
  for (int i = 0; i < n; i++) {
    sum_fraction.numerator += fractions[i].numerator;
    sum_fraction.denominator *= fractions[i].denominator;
  }
  return sum_fraction;
}

int main() {
  int n;
  printf("Nhap so luong phan so: ");
  scanf("%d", &n);

  struct fraction fractions[n];
  input_fractions(n, fractions);

  struct fraction max_fraction = find_max_fraction(n, fractions);
  printf("Phan so lon nhat la: %d/%d\n", max_fraction.numerator,
         max_fraction.denominator);

  struct fraction sum_fraction = sum_fractions(n, fractions);
  printf("Tong cac phan so la: %d/%d\n", sum_fraction.numerator,
         sum_fraction.denominator);

  return 0;
}
   
