//
//  main.c
//  Bai01.TH06
//
//  Created by le thanh tung on 16/11/2023.
//

#include <stdio.h>

typedef struct {
  int tu;
  int mau;
} fraction;

void nhap_phan_so(fraction *f) {
  printf("Nhap tu: ");
  scanf("%d", &f->tu);

  printf("Nhap mau: ");
  scanf("%d", &f->mau);
}

void xuat_phan_so(fraction f) {
  printf("%d/%d", f.tu, f.mau);
}

fraction tong_phan_so(fraction f1, fraction f2) {
  fraction f;

  f.tu = f1.tu * f2.mau + f2.tu * f1.mau;
  f.mau = f1.mau * f2.mau;

  return f;
}

fraction tich_phan_so(fraction f1, fraction f2) {
  fraction f;

  f.tu = f1.tu * f2.tu;
  f.mau = f1.mau * f2.mau;

  return f;
}

int main() {
  fraction f1, f2, f3;

  nhap_phan_so(&f1);
  nhap_phan_so(&f2);

  f3 = tong_phan_so(f1, f2);
  printf("Tong hai phan so: %d/%d\n", f3.tu, f3.mau);

  f3 = tich_phan_so(f1, f2);
  printf("Tich hai phan so: %d/%d\n", f3.tu, f3.mau);

  return 0;
}

