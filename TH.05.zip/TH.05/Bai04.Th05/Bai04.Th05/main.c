//
//  main.c
//  Bai04.Th05
//
//  Created by le thanh tung on 15/11/2023.
//

#include <stdio.h>


int main(int argc, const char * argv[]) {
#include <stdio.h>

void nhapMang(int a[], int n) {
    printf("Nhap mang:\n");
    for (int i = 0; i < n; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }
}

void tongHaiMang(int a[], int b[], int n) {
    int c[n];
    printf("Tong hai mang:\n");
    for (int i = 0; i < n; i++) {
        c[i] = a[i] + b[i];
        printf("c[%d] = %d\n", i, c[i]);
    }
}

void giaoHaiTapHop(int a[], int b[], int n, int m) {
    printf("Giao hai tap hop:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (a[i] == b[j]) {
                printf("%d ", a[i]);
                break;
            }
        }
    }
    printf("\n");
}

void hopHaiTapHop(int a[], int b[], int n, int m) {
    printf("Hop hai tap hop:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    for (int i = 0; i < m; i++) {
        int found = 0;
        for (int j = 0; j < n; j++) {
            if (b[i] == a[j]) {
                found = 1;
                break;
            }
        }
        if (!found) {
            printf("%d ", b[i]);
        }
    }
    printf("\n");
}

int main() {
    int n, m;

    printf("Nhap so phan tu cua mang thu nhat: ");
    scanf("%d", &n);
    int a[n];
    nhapMang(a, n);

    printf("Nhap so phan tu cua mang thu hai: ");
    scanf("%d", &m);
    int b[m];
    nhapMang(b, m);

    tongHaiMang(a, b, n);
    giaoHaiTapHop(a, b, n, m);
    hopHaiTapHop(a, b, n, m);

    return 0;
}

    return 0;
}
