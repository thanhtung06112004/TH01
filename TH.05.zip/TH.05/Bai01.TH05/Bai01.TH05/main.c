//
//  main.c
//  Bai01.TH05
//
//  Created by le thanh tung on 15/11/2023.
//

#include <stdio.h>
//Nhập giá trị cho mảng nguyên có n phần tử (n được nhập từ bàn phím), sau đó tính tổng của các phần tử có giá trị chẵn trên mảng.

int main(int argc, const char * argv[]) {
    
    int n;
     printf("Nhap kich thuoc mang: ");
     scanf("%d", &n);

     int a[n];
     for (int i = 0; i < n; i++) {
       printf("Nhap phan tu thu %d: ", i + 1);
       scanf("%d", &a[i]);
     }

     int sum = 0;
     for (int i = 0; i < n; i++) {
       if (a[i] % 2 == 0) {
         sum += a[i];
       }
     }

     printf("Tong cac phan tu co gia tri chan la: %d\n", sum);

    return 0;
}
