//
//  main.c
//  Bai02.TH05
//
//  Created by le thanh tung on 15/11/2023.
//

#include <stdio.h>

void nhap_mang(int a[], int n) {
  for (int i = 0; i < n; i++) {
    printf("Nhap phan tu thu %d: ", i + 1);
    scanf("%d", &a[i]);
  }
}

void xuat_mang(int a[], int n) {
  for (int i = 0; i < n; i++) {
    printf("%d ", a[i]);
  }
  printf("\n");
}

int tinh_tong_chan(int a[], int n) {
  int sum = 0;
  for (int i = 0; i < n; i++) {
    if (a[i] % 2 == 0) {
      sum += a[i];
    }
  }
  return sum;
}

int main() {
  int n;
  printf("Nhap kich thuoc mang: ");
  scanf("%d", &n);

  int a[n];

  nhap_mang(a, n);

  xuat_mang(a, n);

  int sum = tinh_tong_chan(a, n);

  printf("Tong cac phan tu co gia tri chan la: %d\n", sum);
    return 0;
}
