//
//  main.c
//  Bai01.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình tính tổng S = 1 + 2 + … + n.
    int n;
      int sum = 0;

      printf("Nhập số nguyên dương n: ");
      scanf("%d", &n);

      for (int i = 1; i <= n; i++) {
        sum += i;
      }

      printf("Tổng S = 1 + 2 + ... + n = %d\n", sum);
    return 0;
}
