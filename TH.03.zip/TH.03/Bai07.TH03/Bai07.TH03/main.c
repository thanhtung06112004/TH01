//
//  main.c
//  Bai07.TH03
//
//  Created by le thanh tung on 17/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình tính S = 1 + 2n + 3n + … + nn
    int n;
      long long sum = 0;

      printf("Nhập số nguyên dương n: ");
      scanf("%d", &n);

      for (int i = 1; i <= n; i++) {
        sum += (long long)i * i * i;
      }

    printf("Tổng S = 1 + 2^2 + 3^3 + ... + n^n = %lld\n", sum);
    
    return 0;
}
