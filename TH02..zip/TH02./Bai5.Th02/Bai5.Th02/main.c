//
//  main.c
//  Bai5.Th02
//
//  Created by le thanh tung on 12/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình nhập số giờ làm và lương/giờ rồi tính số tiền lương tổng cộng. Nếu số giờ làm lớn hơn 40 thì những giờ làm dôi ra được tính 1,5 lần.
    int soGioLam, luongGio;

      // Nhập số giờ làm và lương giờ
      printf("Nhap so gio lam: ");
      scanf("%d", &soGioLam);
      printf("Nhap luong gio: ");
      scanf("%d", &luongGio);

      // Tính số giờ làm thêm
      int soGioThem = soGioLam - 40;

      // Tính tổng tiền lương
      int tienLuong = soGioLam * luongGio;
      int tienLuongThem = soGioThem * luongGio * 1.5;
      int tienLuongChung = tienLuong + tienLuongThem;

      // In ra kết quả
      printf("Tong tien luong là: %d\n", tienLuongChung);
    
    return 0;
}
