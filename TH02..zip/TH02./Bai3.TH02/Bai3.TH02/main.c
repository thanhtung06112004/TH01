

#include <stdio.h>
#include <math.h>

int main(int argc, const char * argv[]) {
//    Sử dụng bài 6 (BÀI THỰC HÀNH SỐ 1), nhưng thêm điều kiện kiểm tra có phải là tam giác không? Nếu phải thì tính chu vi, diện tích; nếu không thì in ra không phải.
    float a, b, c;

      // Nhập vào 3 cạnh của tam giác
      printf("Nhap canh a: ");
      scanf("%f", &a);
      printf("Nhap canh b: ");
      scanf("%f", &b);
      printf("Nhap canh c: ");
      scanf("%f", &c);

      // Kiểm tra xem 3 cạnh có tạo thành tam giác hay không
      if (a + b > c && a + c > b && b + c > a) {
        // Tính chu vi tam giác
        float perimeter = a + b + c;

        // Tính diện tích tam giác theo công thức Heron
        float s = (a + b + c) / 2;
        float area = sqrt(s * (s - a) * (s - b) * (s - c));

        // In ra kết quả
        printf("Chu vi tam giac la: %.2f\n", perimeter);
        printf("Dien tich tam giac la: %.2f\n", area);
      } else {
        // Nếu không tạo thành tam giác thì in ra thông báo
        printf("3 canh nay khong tao thanh tam giac.\n");
      }

    return 0;
}
