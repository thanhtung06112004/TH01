//
//  main.c
//  Bai8.TH02
//
//  Created by le thanh tung on 12/11/2023.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    Viết chương trình nhập vào 2 số x, y và 1 trong 4 toán tử +, -, *, /
//    Nếu là + thì in ra kết quả x + y
//    Nếu là – thì in ra kết quả x – y
//    Nếu là * thì in ra kết quả x * y
//    Nếu là / thì in ra kết quả x / y (nếu y = 0 thì thông báo không chia được)
    
    int x, y;
      char toanTu;

      printf("Nhap vao 2 so x va y: ");
      scanf("%d %d", &x, &y);

      printf("nhap vao toan tu: ");
      scanf(" %c", &toanTu);

      switch (toanTu) {
        case '+':
          printf("x + y = %d\n", x + y);
          break;
        case '-':
          printf("x - y = %d\n", x - y);
          break;
        case '*':
          printf("x * y = %d\n", x * y);
          break;
        case '/':
          if (y == 0) {
            printf("khong chia duoc 0\n");
          } else {
            printf("x / y = %d\n", x / y);
          }
          break;
        default:
          printf("toan tu khong hop le\n");
          break;
      }


    return 0;
}
