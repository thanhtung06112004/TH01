//
//  main.c
//  Bai09.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
#include <math.h>
//Viết hàm tính  1 + 1/x + 2/x2 + 3/x3 + … + n/xn

float tinh_tong(int n, float x) {
  float x1 = 1 - pow(1/x, n);
  float x2 = 1 - 1/x;
  float S = x1 / x2;

  return S;
}

int main() {
  int n;
  printf("Nhap so tu nhien n: ");
  scanf("%d", &n);

  float x;
  printf("Nhap so thuc x: ");
  scanf("%f", &x);

  float S = tinh_tong(n, x);

  printf("Tong S = 1 + 1/x + 2/x^2 + ... + n/x^n = %.2f\n", S);
    return 0;
}
