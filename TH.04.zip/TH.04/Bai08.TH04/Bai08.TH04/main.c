//
//  main.c
//  Bai08.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
//Viết hàm tính  1 + 1/x + 1/x2 + … + 1/xn
float tinh_tong(int n, float x) {
  float x1 = 1 + 1/x;
  float x2 = n - 1;
  float S = x1 * x2 / 2;

  return S;
}

int main() {
  int n;
  printf("Nhap so tu nhien n: ");
  scanf("%d", &n);

  float x;
  printf("Nhap so thuc x: ");
  scanf("%f", &x);

  float S = tinh_tong(n, x);
  printf("Tong S = 1 + 1/x + 1/x^2 + ... + 1/x^n = %.2f\n", S);
    return 0;
}
