//
//  main.c
//  Bai02.TH04
//
//  Created by le thanh tung on 14/11/2023.
//

#include <stdio.h>
//Viết hàm tính  1*2* … *n.
int sum(int n) {
    int i, sum = 0;
    for (i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
}
int main() {
    int n, result;
    printf("Nhap n: ");
    scanf("%d", &n);
    result = sum(n);
    printf("Tong n: %d", result);
    return 0;
}
